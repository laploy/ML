import math

# basic computation in R
a = 2 + 3
b = 6/3
c = (3*8)/(2*3)
d = math.log(12)
e = math.sqrt(121)
print('end')
