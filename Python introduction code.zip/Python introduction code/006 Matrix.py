# Matrix
matrix = [[1, 2, 3],
          [4, 5, 6],
          [7, 8, 9]]
a = matrix[1]   # get a row
b = matrix[1][2]    # get row 1 column 2
c = [[1, 2, 3],
          [4, 5, 6],
          [7, 8, 9]]
c[1] = [12, 13, 14]
d = [[1, 2, 3],
          [4, 5, 6],
          [7, 8, 9]]
d[1] = []
print('end')
