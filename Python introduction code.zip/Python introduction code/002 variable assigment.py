# variable assignment & declaration
a = 1
b = 2
c = a + b
k = (a * 2) + (b * 3)
o = 1; p = 'dog'; q = 3
x = y = z = 1       # multiple
l, m, n = 1, 2, 'cat'
print('end')
