# For Loop statement
string = "Hello World"
s = ''
for x in string:
    s += x + ' '
# while loop
start, end = 0, 5
while start <= end:
    print('*')
    start += 1
print('end')
