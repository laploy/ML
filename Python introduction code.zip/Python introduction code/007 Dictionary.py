# Dictionary
a = {'name': 'loy', 'age': 20, 'gender': 'M'}
b = a['name']
c = len(a)
d = 'name' in a
e = list(a.keys())
f = list(a.values())
g = {'name': 'loy', 'age': 20, 'gender': 'M'}
h = g['name'] = 'lap'
i = {'name': 'loy', 'age': 20, 'gender': 'M'}
# delete entry
del i['name']
j = {'name': 'loy', 'age': 20, 'gender': 'M'}
# add entry
l = j['year'] = 3
print('end')
