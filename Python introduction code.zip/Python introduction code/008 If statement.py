# If Statement
x = 1
if x == 1:
    print('same')
elif x > 1:
    print('bigger')
else:
    print('smaller')

print('end')
