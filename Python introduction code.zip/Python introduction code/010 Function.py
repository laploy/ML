# Function
def add1(a1, b1):
    r1 = a1 + b1
    return r1

a = add1(2, 4)

# anonymous function
add2 = lambda a2, b2: a2 + b2

b = add2(10, 20)

print('end')
