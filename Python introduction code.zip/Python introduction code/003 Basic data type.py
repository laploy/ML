# Basic data type
name = 'laploy'     # character
who = name + ' v.'  # string concat
price = 1500        # integer
kilo = 1.5          # floating point
x = price + kilo    # automatic type casting
yes = True          # bool
gen = 123           # integer
gen = 'hello'       # change to string
print('end')
