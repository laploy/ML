# Basic Operators
# Arithmetic
a = (2 + 3) * 2
x, y = 2, 3
b = (x + y) * 2
c = (2 * 3) / 2
d = 2 / (3 * 4)
e = 3 * (4/2)
# tuple and operator +
v = (1, 2, 3)
t = (2, 2, 1)
f = v + t
# relation operator
x1 = a > c
x2 = a < d
x3 = a == b
x4 = a != b
print('end')
