L1 = []  # An empty list
# Four items: indexes 0..3
L2 = [123, 'abc', 1.23, {}]
# Nested sublist
L3 = ['Bob', 40.0, ['dev', 'mgr']]
L4 = list('spam')
L5 = list(range(-4, 4))
x = [1, 2, 3]
y = [1, 2, 3]
z = x + y
# List comprehensions
a1 = [v for v in 'SPAM']
a2 = [v * 4 for v in 'cat']
print('end')
