# Replace missing values with a string
# Column = emergency_contact
# Replace NA with “no”

rm(list = ls())
dat <- read.csv("missing_values.csv", na.strings = "")
dat$emer <- ifelse(is.na(dat$emergency_contact), 'no',
                dat$emergency_contact)

