# Replace missing values with an interpolated estimate
# column = years_seniority
# the values in this column, years seniority, is ordered, 
# greatest to least. This structure can be exploited by 
# interpolating the missing value. This approach is very effective 
# when it is appropriate, usually with time - series data.
rm(list = ls()) # clear work space
setwd("d:/temp") # set current work directory
# import data file
dat <- read.csv("missing_values.csv", na.strings = "")
dat$senior <- ifelse(is.na(dat$years_seniority), 11.5,
                dat$years_seniority)