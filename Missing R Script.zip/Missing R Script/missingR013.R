# Delete rows that are missing critical values 
# Rows that are missing important features can be deleted.
# This is particularly useful when you have the luxury of 
# hand - picking high - quality data
# such as when training a model
rm(list = ls())
dat <- read.csv("missing_values.csv", na.strings = "")
dat <- dat[complete.cases(dat),]

