# Replace missing values with the median
# column = age
# •	Another justifiable way to handle missing-at-random data
rm(list = ls()) # clear work space
setwd("d:/temp") # set current work directory
# import data file
dat <- read.csv("missing_values.csv", na.strings = "")
dat$age.mean <- ifelse(is.na(dat$age),
                    median(dat$age, na.rm = TRUE), dat$age)

