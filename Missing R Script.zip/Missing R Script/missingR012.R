# Column = pets
# Is a feature that missing too many values
# Not enough information available to make reasonable 
# assumptions about how to replace the missing values
# Best policy = delete the column entirely.

rm(list = ls())
dat <- read.csv("missing_values.csv", na.strings = "")
dat <- dat[, !(names(dat) %in% 'pets')]

