# eplace missing values with a dummy
# Column = parking_space
# Filling in a dummy value
# Clearly different from actual values
# Such as a negative rank
# Used to indicate that the feature is not applicable

rm(list = ls())
dat <- read.csv("missing_values.csv", na.strings = "")
dat$park <- ifelse(is.na(dat$parking_space), -99,
                dat$parking_space)
