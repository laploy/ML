# Column = years_seniority, age, income
# Method = multivariate imputation by chained equations(MICE)
# MICE is the method of choice for complex incomplete data
# Good for missing data in more than one variable
# powerful when features are somewhat related

rm(list = ls())
dat <- read.csv("missing_values.csv", na.strings = "")
# A fast, consistent tool for working with data frame
install.packages("dplyr") 
library(dplyr) # attach packages
# Replace missing values using imputation MICE
# Make new dataframe with column years_seniority, 
# age, income with column type = numeric
dat <- dat %>% # make new 3 columns with type numberic	
mutate(
    senior1 = as.numeric(years_seniority),
    age1 = as.numeric(age),
    income1 = as.numeric(income)
    )
# Replace missing values using imputation MICE
keep <- c("senior1", "age1", "income1")
#drop all columns but keep 3 col
dat <- dat[, keep, drop = FALSE] 
install.packages('mice')        # standard command
library(mice)                   # standard command
init = mice(dat, maxit = 0)     # standard command
meth = init$method              # standard command
predM = init$predictorMatrix
# Bayesian linear regression (การวิเคราะห์ถดถอยเชิงเส้นแบบเบยส์)
meth[c("senior1")] = "norm"
Predictive mean matching
meth[c("age1")] = "pmm" # 
meth[c("income1")] = "pmm"
# Replace missing values using imputation MICE
set.seed(103) # seed for pseudo random number generator
imputed = mice(dat, method = meth, predictorMatrix = predM, m = 5)
imputed <- complete(imputed)
