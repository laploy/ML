# Create an indicator variable for "missing"
# Column = pets
# Replacing missing values requires making assumptions.
# Whenever your confidence in those assumptions is low, 
# it is safer to also create a true / false feature 
# indicating that the value was missing.
# This allows many algorithms to learn to weight those differently.
rm(list = ls())
dat <- read.csv("missing_values.csv", na.strings = "")
dat$pet1 <- ifelse(is.na(dat$pet), 0, dat$pets)
dat$pet2 <- complete.cases(dat$pets)

