# Add an indicator variable showing which strings 
# are considered "missing."
# Column = emergency_contact
# There are lots of ways to communicate the concept 
# of "missing" in a string
# Replace no, NA, n / a, None, _,"""",empty,null with 0
# Otherwise = 1
rm(list = ls())
dat <- read.csv("missing_values.csv", na.strings = "")
dat$emer <- ifelse(dat[9] == 'NA' |
     is.na(dat[9]) | dat[9] == 'n/a' |
     dat[9] == 'None' | dat[9] == 'empty' |
     dat[9] == '_' | dat[9] == '""' | dat[9] == 'null', 0, 1)



