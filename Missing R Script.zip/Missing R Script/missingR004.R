rm(list = ls()) # clear work space
setwd("d:/temp") # set current work directory
# import data file
dat <- read.csv("missing_values.csv", na.strings = "")
dat$income4 <- ifelse(is.na(dat$income), 250, dat$income)

