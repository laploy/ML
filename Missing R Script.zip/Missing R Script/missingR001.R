# Replace missing values with the mean
# column = age
# Missing values type = distributed
# Formal name =  Missing Completely at Random (MCAR)
rm(list = ls()) # clear work space
setwd("d:/temp") # set current work directory
# import data file
dat <- read.csv("missing_values.csv", na.strings = "")
dat$age.mean <- ifelse(is.na(dat$age),mean(dat$age, na.rm = TRUE), dat$age)