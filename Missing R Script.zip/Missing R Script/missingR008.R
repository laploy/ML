# eplace missing values with 0
# Column = attending_party
# A missing numerical value can mean zero. 
# In the case of an RSVP, invitees who are not planning 
# to attend sometimes neglect to respond, but guests 
# planning to attend are more likely to.
# In this case, filling in missing blanks with a zero is reasonable
rm(list = ls())
dat <- read.csv("missing_values.csv", na.strings = "")
dat$party <- ifelse(is.na(dat$attending_party), 0, dat$attending_party)