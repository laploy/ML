# Replace missing values with a missing rank
# Column = parking_space
# Our knowledge of how parking spaces are numbered, 
# let us make a guess here
# All the space numbers from 1 - 11
# Missing one might be 12
rm(list = ls())
dat <- read.csv("missing_values.csv", na.strings = "")
dat$park <- ifelse(is.na(dat$parking_space), 12,
                dat$parking_space)


